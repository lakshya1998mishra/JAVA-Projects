import java.util.*;
public class Main {

	public static void main(String[] args){
		//Employee Table
        int[] empno= {1001,1002,1003,1004,1005,1006,1007};
        String[] empname= {"ashish","sushma","rahul","chahat","ranjan","suman","tanmay"};
        String[] datee= {"01/04/2009","23/08/2012","12/11/2008","29/1/2013","16/7/2005","1/1/2000","12/06/2006"};
        char[] desginationcode= {'e','c','k','r','m','e','c'};
        String[] department= {"R&D","PM","ACCT","Front Desk","ENGG","Manfacturing","PM"};
        int[] basic= {2000,3000,1000,12000,50000,23000,29000};
        int[] hra= {8000,12000,8000,6000,20000,9000,12000};
        int[] it= {3000,9000,1000,2000,20000,4400,10000};
        
        //Dearness Allowance
        char[] desginatiocode2= {'e','c','k','r','m'};       
        System.out.println("Enter EmployeeID");
        Scanner ob1=new Scanner(System.in);
        int id=ob1.nextInt();
        int index= id-1000-1;
        System.out.println(" Emp_No. "+" Emp_Name "+" Department "+" Desgination "+" Salary ");
        String desig="";
        int da=0;
        switch(desginationcode[index]) {
        case 'e':
        	desig="Engineer";
        	da=2000;
        	break;
        case 'c':
        	desig="Consultant";
        	da=32000;
        	break;
        case 'k':
        	desig="Clerk";
        	da=12000;
        	break;
        case 'r':
        	desig="Receptionist";
        	da=15000;
        	break;
        case 'm':
        	desig="Manager";
        	da=40000;
        	break;
        }
        
        int salary=basic[index]+hra[index]+da-it[index];
        System.out.println(id+ empname[index] + department[index] + desig+salary );
		}
	}
	

	


